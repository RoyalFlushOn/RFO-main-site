<?php 

class SetupPage {
 const BOOTSTRAP_CSS_OFFLINE = 'css/bootstrap.min.css';
const BOOTSTRAP_CSS_ONLINE = 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css';
const BOOTSTRAP_CSS_ONLINE_4_CSS = 'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css';
const BOOTSTRAP_CSS_ONLINE_4_INTEGRITY = 'sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS';
const JQUERY3_OFFLINE = 'js/jquery-3.3.1.min.js';
const JQUERY3_ONLINE_SRC = 'https://code.jquery.com/jquery-3.3.1.slim.min.js';
const JQUERY3_ONLINE_INTEGRITY = 'sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo';
const BOOTSTRAP_JS_OFFLINE = 'js/bootstrap.min.js';
const BOOTSTRAP_JS_ONLINE_4_SRC = 'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js';
const BOOTSTRAP_JS_ONLINE_4_INTEGRITY = 'sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut';
const BOOTSTRAP_JS_ONLINE_4_POPPER = 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js';
const BOOTSTRAP_CSS_THEME = 'css/theme.css';
  
  function __constructor(){
    
  }
}
?>