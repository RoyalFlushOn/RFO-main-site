<?php 
class User{
  public $fName;
  public $lName;
  public $DOB;
  public $email;
  public $user;
  public $cDate;
  public $status;
  public $level;
  public $dPic;
}
?>