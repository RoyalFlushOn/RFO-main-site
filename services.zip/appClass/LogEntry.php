<?php

class LogEntry {
  private $type;
  private $msg;
  private $dt;
  private $page;
}

?>