<?php

class Responce{
  
  public $status;
  public $errormsg;
  public $flag;
  public $exists;
  public $results;
  public $found;
}

?>