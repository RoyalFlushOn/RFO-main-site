<?php

class RecaptDetails{
    public $siteKey;
    public $secretKey;
}

?>