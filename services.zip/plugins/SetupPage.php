<?php 

define('BOOTSTRAP_CSS_OFFLINE', 'css/bootstrap.min.css');
define('BOOTSTRAP_CSS_ONLINE_3_CSS', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
define('BOOTSTRAP_CSS_ONLINE_CSS', 'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css');
define('BOOTSTRAP_CSS_ONLINE_INTEGRITY', 'sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T');
define('JQUERY3_OFFLINE', 'js/jquery-3.3.1.min.js');
define('JQUERY3_ONLINE_SRC', 'https://code.jquery.com/jquery-3.4.1.min.js');
define('JQUERY3_ONLINE_INTEGRITY', 'sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=');
define('BOOTSTRAP_JS_OFFLINE_3', 'js/bootstrap.min.js');
define('BOOTSTRAP_JS_ONLINE_SRC', 'https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js');
define('BOOTSTRAP_JS_ONLINE_INTEGRITY', 'sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM');
define('BOOTSTRAP_JS_ONLINE_POPPER', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js');
define('BOOTSTRAP_JS_ONLINE_POPPER_INTEGRITY', 'sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1');
define('BOOTSTRAP_CSS_THEME', 'css/theme.css');
define('QUILL_CSS', 'https://cdn.quilljs.com/1.3.6/quill.snow.css');
define('QUILL_JS_SRC', 'https://cdn.quilljs.com/1.3.6/quill.js');

?>